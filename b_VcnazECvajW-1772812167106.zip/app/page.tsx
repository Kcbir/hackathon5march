"use client"

import { useState, useEffect, useCallback } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Phone, PhoneOff, CheckCircle2 } from "lucide-react"

type CallState = "idle" | "connecting" | "listening" | "processing" | "speaking" | "ended"

interface Message {
  id: number
  role: "ai" | "customer"
  text: string
}

interface OrderItem {
  name: string
  quantity: number
}

const DEMO_CONVERSATION: { role: "ai" | "customer"; text: string; delay: number }[] = [
  { role: "ai", text: "Good afternoon!\nThank you for calling Spice Garden.\n\nThis is Petpooja Vaani, your AI ordering assistant.\n\nHow may I help you today?", delay: 0 },
  { role: "customer", text: "Hi, I would like one cappuccino please.", delay: 3000 },
  { role: "ai", text: "Sure, one cappuccino.\nWould you like anything else?", delay: 5000 },
  { role: "customer", text: "Yes, add one veg sandwich.", delay: 8000 },
  { role: "ai", text: "Got it. One cappuccino and one veg sandwich.", delay: 10000 },
  { role: "ai", text: "Your order has been placed successfully.", delay: 12000 },
  { role: "ai", text: "Your order number is 104.\n\nThank you for ordering with Spice Garden!", delay: 14000 },
]

const STATUS_TEXT: Record<CallState, string> = {
  idle: "Tap to start call",
  connecting: "Connecting to customer...",
  listening: "Listening to order...",
  processing: "Understanding order...",
  speaking: "Responding to customer...",
  ended: "Call finished",
}

function BackgroundDoodles() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {/* Subtle decorative circles */}
      <div className="absolute top-20 right-[20%] w-64 h-64 rounded-full bg-petpooja-red/[0.03]" />
      <div className="absolute bottom-20 left-[10%] w-48 h-48 rounded-full bg-petpooja-red/[0.02]" />
    </div>
  )
}

function Waveform({ isActive, color }: { isActive: boolean; color: "red" | "green" }) {
  const bars = 8
  const colorClass = color === "red" ? "bg-petpooja-red" : "bg-green-500"
  
  return (
    <div className="flex items-center justify-center gap-1 h-10">
      {Array.from({ length: bars }).map((_, i) => (
        <motion.div
          key={i}
          className={`w-0.5 rounded-full ${isActive ? colorClass : "bg-gray-200"}`}
          animate={isActive ? {
            height: [4, 16 + Math.random() * 12, 4],
          } : { height: 4 }}
          transition={{
            duration: 0.4 + Math.random() * 0.2,
            repeat: isActive ? Infinity : 0,
            ease: "easeInOut",
            delay: i * 0.04,
          }}
        />
      ))}
    </div>
  )
}

function Navbar() {
  return (
    <nav className="h-16 px-8 flex items-center justify-between bg-white">
      <div className="flex items-center gap-8">
        {/* Petpooja Logo */}
        <div className="flex items-center">
          <span className="text-xl font-semibold tracking-wide text-petpooja-navy">PETP</span>
          <div className="w-5 h-5 rounded-full bg-petpooja-red mx-0.5" />
          <span className="text-xl font-semibold tracking-wide text-petpooja-navy">JA</span>
        </div>
        
        <div className="hidden md:flex items-center gap-6 text-sm text-gray-600">
          <span>Spice Garden</span>
        </div>
      </div>
      
      <div className="flex items-center gap-4">
        <span className="text-xs text-gray-400">Vaani Demo</span>
      </div>
    </nav>
  )
}

function AIAttendantPanel({ 
  callState, 
  onStartCall, 
  onEndCall 
}: { 
  callState: CallState
  onStartCall: () => void
  onEndCall: () => void
}) {
  const isInCall = callState !== "idle" && callState !== "ended"
  const showWaveform = callState === "listening" || callState === "speaking"
  const waveformColor = callState === "listening" ? "red" : "green"
  
  return (
    <div className="flex flex-col items-center justify-center h-full p-6">
      {/* Title */}
      <div className="text-center mb-10">
        <h2 className="text-xl font-semibold text-petpooja-navy">Vaani</h2>
        <p className="text-xs text-gray-400 mt-1">AI Phone Attendant</p>
      </div>
      
      {/* Call Button */}
      <motion.button
        onClick={isInCall ? onEndCall : onStartCall}
        className={`w-16 h-16 rounded-full flex items-center justify-center transition-colors ${
          isInCall 
            ? "bg-gray-800 hover:bg-gray-900" 
            : "bg-petpooja-red hover:bg-red-600"
        }`}
        whileHover={{ scale: 1.03 }}
        whileTap={{ scale: 0.97 }}
      >
        {isInCall ? (
          <PhoneOff className="w-6 h-6 text-white" />
        ) : (
          <Phone className="w-6 h-6 text-white" />
        )}
      </motion.button>
      
      <p className="mt-3 text-xs font-medium text-gray-500">
        {isInCall ? "End Call" : "Start Call"}
      </p>
      
      {/* Status */}
      <motion.p 
        key={callState}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="mt-4 text-xs text-gray-400"
      >
        {STATUS_TEXT[callState]}
      </motion.p>
      
      {/* Waveform */}
      <div className="mt-8 h-10">
        <Waveform isActive={showWaveform} color={waveformColor as "red" | "green"} />
      </div>
    </div>
  )
}

function ConversationPanel({ messages }: { messages: Message[] }) {
  return (
    <div className="flex flex-col h-full">
      <div className="px-5 py-3 border-b border-gray-100">
        <h3 className="text-sm font-medium text-petpooja-navy">Conversation</h3>
      </div>
      
      <div className="flex-1 overflow-y-auto p-5 space-y-3">
        <AnimatePresence mode="popLayout">
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className={`flex ${message.role === "customer" ? "justify-end" : "justify-start"}`}
            >
              <div className={`max-w-[80%] rounded-lg px-3 py-2 ${
                message.role === "ai" 
                  ? "bg-red-50 border border-red-100 text-petpooja-navy" 
                  : "bg-petpooja-navy text-white"
              }`}>
                <p className="text-sm whitespace-pre-line leading-relaxed">{message.text}</p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  )
}

function OrderPanel({ 
  items, 
  orderNumber, 
  isConfirmed 
}: { 
  items: OrderItem[]
  orderNumber: string | null
  isConfirmed: boolean
}) {
  return (
    <div className="flex flex-col h-full bg-gradient-to-b from-red-50/50 to-white">
      <div className="px-5 py-3 border-b border-red-100/50">
        <h3 className="text-sm font-medium text-petpooja-navy">Order</h3>
      </div>
      
      <div className="flex-1 p-5">
        <AnimatePresence mode="popLayout">
          {items.length === 0 ? (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center text-gray-300 mt-12"
            >
              <p className="text-xs">No items yet</p>
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-4"
            >
              {/* Items */}
              <div className="bg-white rounded-lg p-3 border border-red-100/50">
                <p className="text-[10px] font-medium text-petpooja-red uppercase tracking-wider mb-2">Items</p>
                <div className="space-y-1">
                  {items.map((item, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="flex justify-between items-center py-1.5"
                    >
                      <span className="text-sm text-gray-700">{item.name}</span>
                      <span className="text-sm font-medium text-petpooja-red">x{item.quantity}</span>
                    </motion.div>
                  ))}
                </div>
              </div>
              
              {/* Order Number */}
              {orderNumber && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="bg-petpooja-red/10 rounded-lg p-3"
                >
                  <p className="text-[10px] font-medium text-petpooja-red uppercase tracking-wider mb-1">Order #</p>
                  <p className="text-xl font-bold text-petpooja-red">{orderNumber}</p>
                </motion.div>
              )}
              
              {/* Status */}
              {isConfirmed && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="bg-green-50 rounded-lg p-3 flex items-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4 text-green-500" />
                  <span className="text-xs font-medium text-green-600">Order Confirmed</span>
                </motion.div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}

export default function PetpoojaVaani() {
  const [callState, setCallState] = useState<CallState>("idle")
  const [messages, setMessages] = useState<Message[]>([])
  const [orderItems, setOrderItems] = useState<OrderItem[]>([])
  const [orderNumber, setOrderNumber] = useState<string | null>(null)
  const [isConfirmed, setIsConfirmed] = useState(false)
  
  const resetCall = useCallback(() => {
    setMessages([])
    setOrderItems([])
    setOrderNumber(null)
    setIsConfirmed(false)
    setCallState("idle")
  }, [])
  
  const startCall = useCallback(() => {
    resetCall()
    setCallState("connecting")
    
    // Simulate connection delay
    setTimeout(() => {
      setCallState("speaking")
      
      // Start the demo conversation
      let messageId = 0
      DEMO_CONVERSATION.forEach((item, index) => {
        setTimeout(() => {
          // Update call state based on who's talking
          if (item.role === "ai") {
            setCallState("speaking")
          } else {
            setCallState("listening")
          }
          
          setMessages(prev => [...prev, { 
            id: messageId++, 
            role: item.role, 
            text: item.text 
          }])
          
          // Extract order items at specific points
          if (item.text.includes("Got it. One cappuccino and one veg sandwich")) {
            setOrderItems([
              { name: "Cappuccino", quantity: 1 },
              { name: "Veg Sandwich", quantity: 1 }
            ])
          }
          
          // Set order number and confirm
          if (item.text.includes("order number is 104")) {
            setOrderNumber("104")
            setIsConfirmed(true)
            
            // End call shortly after
            setTimeout(() => {
              setCallState("ended")
            }, 2000)
          }
        }, item.delay + 1500) // Add 1.5s for initial connection
      })
    }, 1500)
  }, [resetCall])
  
  const endCall = useCallback(() => {
    setCallState("ended")
  }, [])
  
  // Cycle through states during active call
  useEffect(() => {
    if (callState === "speaking" || callState === "listening") {
      const timeout = setTimeout(() => {
        if (callState === "speaking") {
          setCallState("processing")
          setTimeout(() => setCallState("listening"), 500)
        }
      }, 2000)
      return () => clearTimeout(timeout)
    }
  }, [callState, messages])
  
  return (
    <div className="min-h-screen bg-white flex flex-col">
      <BackgroundDoodles />
      <Navbar />
      
      <main className="flex-1 grid grid-cols-1 lg:grid-cols-[240px_1fr_260px] relative z-10">
        {/* Left Panel - AI Attendant */}
        <div className="border-r border-gray-100">
          <AIAttendantPanel 
            callState={callState}
            onStartCall={startCall}
            onEndCall={endCall}
          />
        </div>
        
        {/* Center Panel - Conversation */}
        <div className="bg-gray-50/50 min-h-[500px] lg:min-h-0">
          <ConversationPanel messages={messages} />
        </div>
        
        {/* Right Panel - Order */}
        <div className="border-l border-gray-100">
          <OrderPanel 
            items={orderItems}
            orderNumber={orderNumber}
            isConfirmed={isConfirmed}
          />
        </div>
      </main>
    </div>
  )
}
